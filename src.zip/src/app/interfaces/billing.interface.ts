export interface Billing {
  invoiceNo: string;
  patientName: string;
  amount: number;
  date: string;
  status: string;
} 