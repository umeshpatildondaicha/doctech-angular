export { DoctorsComponent } from './doctors.component';
export { AdminDoctorCreateComponent } from './doctor-create/doctor-create.component';

