export { NotesDialogComponent } from './notes-dialog.component';
export type { NotesDialogData } from './notes-dialog.component';

